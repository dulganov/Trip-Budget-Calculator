<template>
  <div class="converter">
    <h3>Конвертер валют</h3>
    <div class="fields">
      <input
        v-model.number="amount"
        type="number"
        placeholder="Сумма"
      />

      <select v-model="from">
        <option v-for="code in Object.keys(rates)" :key="code" :value="code">
          {{ code }}
        </option>
      </select>

      →

      <select v-model="to">
        <option v-for="code in Object.keys(rates)" :key="code" :value="code">
          {{ code }}
        </option>
      </select>
    </div>

    <p class="result">
      <strong>{{ result.toFixed(2) }} {{ to }}</strong>
    </p>
  </div>
</template>

<script>
export default {
  props: { rates: Object },
  data() {
    return {
      amount: 100,
      from: 'USD',
      to: 'EUR'
    };
  },
  computed: {
    result() {
      const fromRate = this.rates[this.from];
      const toRate = this.rates[this.to];
      return (this.amount / fromRate) * toRate;
    }
  }
};
</script>

<style>
.converter {
  background: #f8f9fa;
  padding: 15px;
  border-radius: 8px;
  margin: 20px 0;
}

.converter .fields {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
}

.converter input, .converter select {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
}

.converter .result {
  margin-top: 10px;
  font-size: 1.1em;
}
</style>
