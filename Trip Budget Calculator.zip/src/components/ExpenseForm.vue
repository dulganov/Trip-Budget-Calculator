<template>
  <form @submit.prevent="handleSubmit" class="expense-form">
    <select v-model="expense.category" required>
      <option value="" disabled>Категория</option>
      <option value="housing">Жильё</option>
      <option value="transport">Транспорт</option>
      <option value="food">Еда</option>
      <option value="entertainment">Развлечения</option>
    </select>

    <input 
      v-model.number="expense.amount"
      type="number"
      placeholder="Сумма"
      min="0.01"
      step="0.01"
      class="{ 'invalid': isInvalidAmount }"
      required
    />

    <select v-model="expense.currency" required>
      <option 
        v-for="(rate, code) in rates"
        :key="code"
        :value="code"
      >
        {{ code }} ({{ rate.toFixed(3) }} за 1 {{ baseCurrency }})
      </option>
    </select>

    <button type="submit">Добавить</button>
  </form>
</template>

<script>
export default {
  computed: {
  isInvalidAmount() {
    return isNaN(this.expense.amount) || this.expense.amount <= 0;
    }
  },
  props: {
    rates: Object,
    baseCurrency: String
  },
  emits: ['add'],
  data() {
    return {
      expense: {
        category: '',
        amount: 0,
        currency: this.baseCurrency || 'USD'
      }
    };
  },
  methods: {
  handleSubmit() {
    if (this.isInvalidAmount) return;  // Прерываем, если ошибка
    this.$emit('add', { ...this.expense });  // Отправляем копию объекта
    this.resetForm();  // Сброс формы
  },
  resetForm() {
  this.expense.category = '';
  this.expense.amount = 0;
  this.expense.currency = this.baseCurrency || 'USD';  // Дефолт
  }
}

  
};
</script>

<style>
.expense-form {
  display: grid;
  grid-template-columns: 1fr 1fr 1fr auto;
  gap: 10px;
  margin-bottom: 20px;
}

.expense-form select, .expense-form input {
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
}
.expense-form input.invalid {
  border-color: #dc3545;  /* Красный цвет границы */
}

.expense-form button {
  padding: 8px 16px;
  background: #2c3e50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
</style>
