export const budgetStore = {
  state: {
    expenses: [],
    baseCurrency: 'USD',
    exchangeRates: { USD: 1, EUR: 0.85, GBP: 0.73, JPY: 110 },
    shareLink: null
  },

  addExpense(expense) {
    this.state.expenses.push(expense);
  },

  setExchangeRates(rates) {
    this.state.exchangeRates = rates;
  },

  generateShareLink() {
    const id = Math.random().toString(36).substring(2, 10);
    this.state.shareLink = `${window.location.origin}/?trip=${id}`;
  },

  resetShareLink() {
    this.state.shareLink = null;
  }
};
