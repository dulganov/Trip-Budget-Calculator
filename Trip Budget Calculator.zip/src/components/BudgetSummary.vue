<template>
  <div class="summary">
    <h3>Распределение бюджета ({{ baseCurrency }})</h3>

    <p v-if="!expenses.length" class="no-data">
      Нет данных о расходах. Добавьте первый расход!
    </p>

    <div
    v-for="(total, category) in totals"
    :key="category"
    class="bar">

      <span class="label">{{ category }}:</span>
      <div class="progress">
        <div
          class="fill"
          :style="{ width: `${getPercentage(total)}%`, backgroundColor: getColor(category) }"
        ></div>
      </div>
      <span class="value">{{ total.toFixed(2) }}</span>
    </div>

    <p v-if="totalSum > 0"><strong>Итого: {{ totalSum.toFixed(2) }} {{ baseCurrency }}</strong></p>
  </div>
</template>

<script>
export default {
  props: {
    expenses: Array,
    rates: Object,
    baseCurrency: String
  },
  computed: {
    totals() {
      if (!this.expenses.length || !Object.keys(this.rates).length) {
        return {}; // Возвращаем пустой объект
      }
      const totals = {};
      this.expenses.forEach(exp => {
        if (!this.rates[exp.currency]) return; // Пропускаем, если курс неизвестен
        const amountInBase = exp.amount / this.rates[exp.currency];
        totals[exp.category] = (totals[exp.category] || 0) + amountInBase;
      });
      return totals;
    },
    totalSum() {
      const values = Object.values(this.totals);
      return values.length ? values.reduce((a, b) => a + b, 0) : 0;
    }
  },
  methods: {
    getPercentage(value) {
      if (this.totalSum === 0) return 0; // Защита от деления на ноль
      return (value / this.totalSum) * 100;
    },
    getColor(category) {
      const colors = {
        housing: '#FF6B6B',
        transport: '#4ECDC4',
        food: '#45B7D1',
        entertainment: '#96CEB4'
      };
      return colors[category] || '#6C5CE7';
    }
  }
};
</script>

<style>
.summary {
  margin: 20px 0;
  font-family: Arial, sans-serif;
}

.bar {
  display: flex;
  align-items: center;
  margin: 10px 0;
}

.label {
  width: 120px;
  font-weight: 500;
  color: #2c3e50;
}

.progress {
  flex: 1;
  height: 20px;
  background: #eee;
  border-radius: 10px;
  overflow: hidden;
  margin: 0 15px;
}

.fill {
  height: 100%;
  transition: width 0.5s ease-in-out;
}

.value {
  min-width: 80px;
  text-align: right;
  font-weight: bold;
  color: #2c3e50;
}

p {
  margin-top: 20px;
  font-size: 1.1em;
  font-weight: bold;
  color: #2c3e50;
}
</style>
