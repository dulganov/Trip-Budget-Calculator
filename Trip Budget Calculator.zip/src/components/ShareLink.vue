<template>
  <div class="share-link">
    <h3>Поделиться бюджетом</h3>
    
    <button
      v-if="!shareLink && !isGenerating"
      @click="generateLink"
      class="btn generate"
    >
      Создать ссылку
    </button>

    <p v-if="isGenerating">Создаётся ссылка...</p>

    <div v-else-if="shareLink">
      <input :value="shareLink" readonly class="link-input" />
      <button @click="copyLink" class="btn copy">Скопировать</button>
      <button @click="resetLink" class="btn reset">Удалить</button>
    </div>

    <p v-if="copied" class="success">Ссылка скопирована!</p>
    <p v-if="error" class="error">{{ error }}</p>
  </div>
</template>

<script>
import { budgetStore } from '../store';

export default {
  data() {
    return {
      copied: false,
      isGenerating: false,  // Индикатор генерации
      error: ''         // Сообщение об ошибке
    };
  },
  computed: {
    shareLink() {
      return budgetStore.state.shareLink;
    }
  },
  methods: {
    async generateLink() {
      this.isGenerating = true;
      this.error = '';
      
      try {
        await budgetStore.generateShareLink();  // Предполагаем, что метод асинхронный
      } catch (err) {
        this.error = 'Не удалось создать ссылку. Попробуйте ещё раз.';
      } finally {
        this.isGenerating = false;
      }
    },
    async copyLink() {
      try {
        await navigator.clipboard.writeText(this.shareLink);
        this.copied = true;
        setTimeout(() => (this.copied = false), 2000);
      } catch (err) {
        this.error = 'Не удалось скопировать ссылку. Разрешите доступ к буферу обмена.';
      }
    },
    resetLink() {
      budgetStore.resetShareLink();
      this.copied = false;
      this.error = '';  // Очищаем ошибки при сбросе
    }
  }
};
</script>


<style>
.share-link {
  margin: 20px 0;
  padding: 15px;
  background-color: #f8f9fa;
  border-radius: 8px;
}

.btn {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 0.9em;
}

.generate {
  background-color: #007bff;
  color: white;
}

.copy {
  background-color: #28a745;
  color: white;
  margin-left: 10px;
}

.reset {
  background-color: #dc3545;
  color: white;
  margin-left: 10px;
}

.link-input {
  width: 60%;
  padding: 8px;
  border: 1px solid #ddd;
  border-radius: 4px;
  font-family: monospace;
  margin-right: 10px;
}

.success {
  color: #28a745;
  margin-top: 10px;
  font-style: italic;
}

.error {
  color: #dc3545;
  margin-top: 10px;
  font-style: italic;
}
</style>
