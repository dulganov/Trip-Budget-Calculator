<template>
  <div class="app">
    <header>
      <h1>Калькулятор бюджета поездки</h1>
    </header>

    <main>
      <ExpenseForm
        :rates="rates"
        :baseCurrency="baseCurrency"
        @add="addExpense"
      />

      <CurrencyConverter :rates="rates" />

      <BudgetSummary
        :expenses="expenses"
        :rates="rates"
        :baseCurrency="baseCurrency"
      />

      <ShareLink />
    </main>
  </div>
</template>

<script>
import ExpenseForm from './components/ExpenseForm.vue';
import CurrencyConverter from './components/CurrencyConverter.vue';
import BudgetSummary from './components/BudgetSummary.vue';
import ShareLink from './components/ShareLink.vue';
import { budgetStore } from './store';

export default {
  components: {
    ExpenseForm,
    CurrencyConverter,
    BudgetSummary,
    ShareLink
  },
  data() {
    return {
      baseCurrency: budgetStore.state.baseCurrency,
      rates: budgetStore.state.exchangeRates,
      expenses: budgetStore.state.expenses
    };
  },
  methods: {
    addExpense(expense) {
      budgetStore.addExpense(expense);
    }
  }
};
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

.app {
  max-width: 900px;
  margin: 0 auto;
  padding: 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  color: #333;
  line-height: 1.6;
}

header {
  text-align: center;
  margin-bottom: 30px;
}

h1 {
  color: #2c3e50;
  margin: 0;
  font-size: 2.2rem;
}

main {
  display: grid;
  gap: 25px;
}

/* Адаптивная сетка */
@media (min-width: 768px) {
  main {
    grid-template-columns: 1fr 1fr;
  }
}

@media (max-width: 767px) {
  main {
    grid-template-columns: 1fr;
  }
  
  h1 {
    font-size: 1.8rem;
  }
}

.section {
  background-color: #ffffff;
  border-radius: 12px;
  padding: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
}

.expense-form,
.converter,
.summary,
.share-link {
  width: 100%;
}

button:focus,
input:focus,
select:focus {
  outline: none;
  box-shadow: 0 0 0 2px #007bff;
}

* {
  transition: all 0.3s ease;
}
</style>
